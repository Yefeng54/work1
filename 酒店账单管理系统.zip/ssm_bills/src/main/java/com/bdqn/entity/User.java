package com.bdqn.entity;

import lombok.Data;

@Data
public class User {
    private Integer id;
    private String userMame;
    private String loginName;
    private String pwd;
    private String sex;

}
