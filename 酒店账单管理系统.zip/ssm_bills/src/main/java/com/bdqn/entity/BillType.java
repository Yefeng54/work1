package com.bdqn.entity;

import lombok.Data;

@Data
public class BillType {
    private Integer id;
    private String name;
}
